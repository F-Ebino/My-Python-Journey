import sqlite3

datbase_connect = sqlite3.connect('spider_web.sqlite')
database_cursor = datbase_connect.cursor()

database_cursor.execute('''UPDATE Pages SET new_rank=1.0, old_rank=0.0''')
datbase_connect.commit()

database_cursor.close()

print("All pages set to a rank of 1.0")
