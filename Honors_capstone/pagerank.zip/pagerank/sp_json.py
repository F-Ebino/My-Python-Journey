import sqlite3

database_connect = sqlite3.connect('asura_index.sqlite')
database_cursor = database_connect.cursor()

print("Creating JSON output on asura_index.js...")
howmany = int(input("How many nodes? ")) - 1

database_cursor.execute('''SELECT COUNT(from_id) AS inbound, old_rank, new_rank, id, url 
    FROM Pages JOIN Links ON Pages.id = Links.to_id
    WHERE html IS NOT NULL AND ERROR IS NULL
    GROUP BY id ORDER BY id,inbound''')

file_handle = open('asura_index.js','w')
nodes = list()
maxrank = None
minrank = None
for row in database_cursor :
    nodes.append(row)
    rank = row[2]
    if maxrank is None or maxrank < rank: maxrank = rank
    if minrank is None or minrank > rank : minrank = rank
    if len(nodes) > howmany : 
        break

if maxrank == minrank or maxrank is None or minrank is None:
    print("Error - please run sprank.py to compute page rank")
    quit()

file_handle.write('spiderJson = {"nodes":[\n')
count = 0
map = dict()
ranks = dict()
#row[0]=inbound, row[2]=new_rank, row[3]=id
for row in nodes :
    if count > 0 : file_handle.write(',\n')
    # print row
    rank = row[2]
    rank = 19 * ( (rank - minrank) / (maxrank - minrank) ) 
    file_handle.write('{'+'"weight":'+str(row[0])+',"rank":'+str(rank)+',')
    file_handle.write(' "id":'+str(row[3])+', "url":"'+row[4]+'"}')
    map[row[3]] = count
    ranks[row[3]] = rank
    count = count + 1
file_handle.write('],\n')

database_cursor.execute('''SELECT DISTINCT from_id, to_id FROM Links''')
file_handle.write('"links":[\n')

count = 0
#row[0] here refers to from_id in the links table
#row[1] refers to the to_id in the links table
for row in database_cursor :
    # print row
    if row[0] not in map or row[1] not in map : continue
    if count > 0 : file_handle.write(',\n')
    rank = ranks[row[0]]
    srank = 19 * ( (rank - minrank) / (maxrank - minrank) ) 
    file_handle.write('{"source":'+str(map[row[0]])+',"target":'+str(map[row[1]])+',"value":3}')
    count = count + 1
file_handle.write(']};')
file_handle.close()
database_cursor.close()

print("Open force.html in a browser to view the visualization")
