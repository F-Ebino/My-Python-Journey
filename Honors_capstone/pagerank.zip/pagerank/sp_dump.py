import sqlite3

database_connect = sqlite3.connect('asura_index.sqlite')
database_cursor = database_connect.cursor()

database_cursor.execute('''SELECT COUNT(to_id) AS outbound, old_rank, new_rank, id, url 
     FROM Pages JOIN Links ON Pages.id = Links.from_id
     WHERE html IS NOT NULL
     GROUP BY id ORDER BY outbound DESC''')

print("!!!NOW PRINTING OUTBOUND HEIRACHY!!!")
count = 0
for row in database_cursor :
    if count < 50 : print(row)
    count = count + 1

database_cursor.execute('''SELECT COUNT(from_id) AS inbound, old_rank, new_rank, id, url 
     FROM Pages JOIN Links ON Pages.id = Links.to_id
     WHERE html IS NOT NULL
     GROUP BY id ORDER BY inbound DESC''')

print("!!!NOW PRINTING INBOUND HEIRACHY!!!")
count = 0
for row in database_cursor :
    if count < 50 : print(row)
    count = count + 1




print(count, 'rows.')
database_cursor.close()
